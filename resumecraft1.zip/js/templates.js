/* ResumeCraft — template renderers. Each returns an HTML string for the A4 sheet. */
"use strict";

RC.esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

RC.getPath = (obj, path) => path.split(".").reduce((o, k) => (o == null ? o : o[k]), obj);
RC.setPath = (obj, path, val) => {
  const keys = path.split(".");
  const last = keys.pop();
  const target = keys.reduce((o, k) => o[k], obj);
  target[last] = val;
};

/* editable element bound to a state path */
const ed = (r, path, ph, tag = "span", cls = "") =>
  `<${tag}${cls ? ` class="${cls}"` : ""} contenteditable="plaintext-only" spellcheck="false" role="textbox" aria-label="${RC.esc(ph)}" data-path="${path}" data-ph="${RC.esc(ph)}">${RC.esc(RC.getPath(r, path))}</${tag}>`;

const head = (title, key, canAdd = true) =>
  `<div class="sec-head"><h2>${title}</h2>${canAdd ? `<button type="button" class="add-inline" data-add="${key}" aria-label="Add ${title.toLowerCase()} entry" title="Add ${title.toLowerCase()}">+</button>` : ""}</div>`;

const rm = (key, i) => `<button type="button" class="rm-inline" data-rm="${key}.${i}" aria-label="Remove this entry">Remove</button>`;

const bullets = (r, key, i) => {
  const list = r[key][i].bullets || [];
  return `<ul class="bl">${list.map((_, b) => ed(r, `${key}.${i}.bullets.${b}`, "Describe what you did and the result", "li")).join("")}</ul>` +
    `<button type="button" class="add-bullet" data-add-bullet="${key}.${i}" aria-label="Add bullet point">+ bullet</button>`;
};

const hint = (txt) => `<p class="empty-hint">${txt}</p>`;
const secWrap = (cls, empty, inner) => `<section class="sec ${cls}${empty ? " is-empty" : ""}">${inner}</section>`;

/* ---- section blocks (shared by templates) ---- */
const S = {
  summary: (r) => secWrap("", !r.summary.trim(),
    head("Summary", "summary", false) + ed(r, "summary", "Write 2–3 sentences about who you are and what you do best.", "p")),

  education: (r) => secWrap("", !r.education.length,
    head("Education", "education") +
    (r.education.length ? r.education.map((e, i) => `
      <div class="entry-x edu-entry">${rm("education", i)}
        <div class="row"><span class="nm">${ed(r, `education.${i}.degree`, "Degree")}</span><span class="when">${ed(r, `education.${i}.year`, "Year")}</span></div>
        <div class="dim">${ed(r, `education.${i}.institution`, "Institution")}${ed(r, `education.${i}.score`, "CGPA / %", "span", "score")}</div>
      </div>`).join("") : hint("Click + to add your education"))),

  experience: (r) => secWrap("", !r.experience.length,
    head("Experience", "experience") +
    (r.experience.length ? r.experience.map((e, i) => `
      <div class="entry-x">${rm("experience", i)}
        <div class="row"><span class="nm">${ed(r, `experience.${i}.role`, "Role / Job title")}</span><span class="when">${ed(r, `experience.${i}.duration`, "Duration")}</span></div>
        <div class="dim">${ed(r, `experience.${i}.company`, "Company")}</div>
        ${bullets(r, "experience", i)}
      </div>`).join("") : hint("Click + to add experience or an internship"))),

  projects: (r) => secWrap("", !r.projects.length,
    head("Projects", "projects") +
    (r.projects.length ? r.projects.map((p, i) => `
      <div class="entry-x">${rm("projects", i)}
        <div class="row"><span class="nm">${ed(r, `projects.${i}.name`, "Project name")}</span><span class="when">${ed(r, `projects.${i}.link`, "Link (live / repo)")}</span></div>
        <div class="dim proj-tech">${ed(r, `projects.${i}.tech`, "Tech stack")}</div>
        ${bullets(r, "projects", i)}
      </div>`).join("") : hint("Click + to add a project"))),

  skillsLines: (r) => secWrap("", !r.skills.length,
    head("Skills", "skills") +
    (r.skills.length ? r.skills.map((s, i) => `
      <div class="entry-x skill-line">${rm("skills", i)}<span class="cat">${ed(r, `skills.${i}.category`, "Category")}</span>${ed(r, `skills.${i}.items`, "Comma-separated skills")}</div>`).join("")
      : hint("Click + to add a skill category"))),

  skillsBadges: (r) => secWrap("", !r.skills.length,
    head("Skills", "skills") +
    (r.skills.length ? r.skills.map((s, i) => {
      const items = (s.items || "").split(",").map((x) => x.trim()).filter(Boolean);
      return `<div class="entry-x skill-grp">${rm("skills", i)}
        <div class="cat">${ed(r, `skills.${i}.category`, "Category")}</div>
        <div class="badges" data-jump="skills.${i}.items" title="Click to edit skills" tabindex="0" role="button" aria-label="Edit ${RC.esc(s.category || "skills")} list">${items.length ? items.map((t) => `<span class="badge">${RC.esc(t)}</span>`).join("") : '<span class="empty-hint">Click to add skills</span>'}</div>
      </div>`;
    }).join("") : hint("Click + to add a skill category"))),
};

const contact = (r) => `<div class="contact">
  ${ed(r, "personal.email", "email@example.com")}${ed(r, "personal.phone", "Phone")}${ed(r, "personal.location", "Location")}${ed(r, "personal.linkedin", "LinkedIn URL")}${ed(r, "personal.github", "GitHub / Portfolio")}
</div>`;

/* ---- templates ---- */
RC.templates = {
  classic: (r) => `
    <header class="hd">
      <h1>${ed(r, "personal.name", "Your Full Name")}</h1>
      ${ed(r, "personal.role", "Role / Headline", "div", "role")}
      ${contact(r)}
    </header>
    ${S.summary(r)}${S.education(r)}${S.experience(r)}${S.projects(r)}${S.skillsLines(r)}`,

  modern: (r) => `
    <header class="hd">
      <div><h1>${ed(r, "personal.name", "Your Full Name")}</h1>${ed(r, "personal.role", "Role / Headline", "div", "role")}</div>
      ${contact(r)}
    </header>
    <div class="cols">
      <div class="main">${S.summary(r)}${S.experience(r)}${S.projects(r)}</div>
      <aside class="side">${S.skillsBadges(r)}${S.education(r)}</aside>
    </div>`,

  executive: (r) => `
    <header class="hd">
      <h1>${ed(r, "personal.name", "Your Full Name")}</h1>
      ${ed(r, "personal.role", "Role / Headline", "div", "role")}
      ${contact(r)}
    </header>
    ${S.summary(r)}${S.skillsLines(r)}${S.experience(r)}${S.projects(r)}${S.education(r)}`
};

RC.render = (state) => RC.templates[state.settings.template](state.resume);
