/* ResumeCraft — app logic: auth, persistence, editor, preview, controls */
"use strict";

(() => {
  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const K = { session: "rc:session", users: "rc:users", hc: "rc:hc", draft: (id) => "rc:draft:" + id };

  /* ---------- safe storage ---------- */
  const store = {
    get(k, fb = null) { try { const v = localStorage.getItem(k); return v == null ? fb : JSON.parse(v); } catch { return fb; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { return false; } },
    del(k) { try { localStorage.removeItem(k); } catch { /* ignore */ } }
  };

  const FONTS = {
    inter: '"Inter", system-ui, sans-serif', jakarta: '"Plus Jakarta Sans", system-ui, sans-serif',
    plex: '"IBM Plex Sans", system-ui, sans-serif', lora: '"Lora", Georgia, serif',
    source: '"Source Serif 4", Georgia, serif', georgia: 'Georgia, "Times New Roman", serif', arial: "Arial, Helvetica, sans-serif"
  };
  const A4_PX = 297 * 96 / 25.4;

  let user = null;
  let state = { resume: RC.blankResume(), settings: RC.defaultSettings() };
  let open = new Set(["personal"]);
  let zoom = "fit";
  let undoSnap = null;
  let showMetrics = false;
  let lastRenderMs = 0;

  /* ---------- toast ---------- */
  let toastTimer;
  function toast(msg, actionLabel, fn) {
    const t = $("#toast");
    t.textContent = msg + " ";
    if (actionLabel) {
      const b = document.createElement("button");
      b.className = "link-btn"; b.style.color = "#fff"; b.textContent = actionLabel;
      b.onclick = () => { fn(); t.hidden = true; };
      t.append(b);
    }
    t.hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => (t.hidden = true), 6000);
  }

  /* ---------- persistence ---------- */
  let saveTimer;
  function setStatus(saving, failed) {
    $("#saveStatus").classList.toggle("saving", saving);
    $("#saveText").textContent = failed ? "Couldn't save (storage full)" : saving ? "Saving…" : "Saved automatically";
  }
  function scheduleSave() {
    setStatus(true);
    clearTimeout(saveTimer);
    saveTimer = setTimeout(saveNow, 350);
  }
  function saveNow() {
    clearTimeout(saveTimer);
    if (!user) return;
    setStatus(false, !store.set(K.draft(user.id), state));
  }
  window.addEventListener("beforeunload", saveNow);
  document.addEventListener("visibilitychange", () => { if (document.hidden) saveNow(); });

  function normalise(d) {
    const base = RC.blankResume(), s = RC.defaultSettings();
    const r = d && d.resume ? d.resume : {};
    return {
      resume: {
        personal: { ...base.personal, ...(r.personal || {}) },
        summary: r.summary || "",
        education: Array.isArray(r.education) ? r.education : [],
        experience: Array.isArray(r.experience) ? r.experience : [],
        projects: Array.isArray(r.projects) ? r.projects : [],
        skills: Array.isArray(r.skills) ? r.skills : []
      },
      settings: { ...s, ...((d && d.settings) || {}) }
    };
  }

  /* ---------- auth ---------- */
  async function hash(s) {
    try {
      const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("rc|" + s));
      return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
    } catch { let h = 5381; for (const c of s) h = ((h << 5) + h + c.charCodeAt(0)) | 0; return "d" + h; }
  }

  function showAuth() {
    $("#app").hidden = true; $("#auth").hidden = false; $("#authEmail").focus();
  }
  function startSession(u) {
    user = u;
    store.set(K.session, u);
    const draft = store.get(K.draft(u.id));
    state = draft ? normalise(draft) : { resume: RC.studentSample(), settings: RC.defaultSettings() };
    if (!draft) store.set(K.draft(u.id), state);
    open = new Set(["personal"]);
    $("#auth").hidden = true; $("#app").hidden = false;
    $("#userLabel").textContent = u.guest ? "Guest" : (u.name || u.email);
    applySettingsUI(); renderForm(); renderPreview(); setStatus(false);
    $("#editor").focus({ preventScroll: true });
  }

  $("#authForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const err = $("#authError"), email = $("#authEmail").value.trim().toLowerCase(), pass = $("#authPass").value, name = $("#authName").value.trim();
    err.textContent = "";
    if (!/^\S+@\S+\.\S+$/.test(email)) { err.textContent = "Please enter a valid email address."; $("#authEmail").focus(); return; }
    if (pass.length < 4) { err.textContent = "Password must be at least 4 characters."; $("#authPass").focus(); return; }
    const users = store.get(K.users, {}), h = await hash(pass);
    if (users[email]) {
      if (users[email].hash !== h) { err.textContent = "Incorrect password for this email."; $("#authPass").focus(); return; }
    } else {
      users[email] = { name, hash: h };
      store.set(K.users, users);
    }
    $("#authPass").value = "";
    startSession({ id: "u:" + email, email, name: name || users[email].name || "", guest: false });
  });
  $("#guestBtn").addEventListener("click", () => startSession({ id: "guest", name: "Guest", guest: true }));
  $("#signOutBtn").addEventListener("click", () => { saveNow(); store.del(K.session); user = null; showAuth(); });

  /* ---------- settings UI ---------- */
  function applySettingsUI() {
    const s = state.settings;
    $$("[data-template]").forEach((b) => b.setAttribute("aria-checked", String(b.dataset.template === s.template)));
    $("#fontSel").value = s.font; $("#sizeSel").value = s.size; $("#spaceSel").value = s.space;
    $("#accentNote").hidden = s.template !== "classic";
    const sw = $("#swatches");
    sw.innerHTML = RC.ACCENTS.map((c) => `<button type="button" class="swatch" role="radio" style="background:${c}" data-color="${c}" aria-label="Accent colour ${c}" aria-checked="${c.toLowerCase() === s.accent.toLowerCase()}"></button>`).join("") +
      `<label class="swatch-custom" title="Custom colour"><span aria-hidden="true">+</span><input type="color" id="customColor" value="${s.accent}" aria-label="Custom accent colour"></label>`;
  }
  function applySheetStyle() {
    const sh = $("#sheet"), s = state.settings;
    sh.className = "sheet t-" + (s.template === "executive" ? "exec" : s.template);
    sh.style.setProperty("--ra", s.accent);
    sh.style.setProperty("--rf", FONTS[s.font] || FONTS.inter);
    sh.style.setProperty("--rs", s.size);
    sh.style.setProperty("--sp", s.space);
  }
  function setSetting(k, v) { state.settings[k] = v; applySettingsUI(); renderPreview(); scheduleSave(); }

  $$("[data-template]").forEach((b) => b.addEventListener("click", () => setSetting("template", b.dataset.template)));
  $("#fontSel").addEventListener("change", (e) => setSetting("font", e.target.value));
  $("#sizeSel").addEventListener("change", (e) => setSetting("size", e.target.value));
  $("#spaceSel").addEventListener("change", (e) => setSetting("space", e.target.value));
  $("#swatches").addEventListener("click", (e) => { const b = e.target.closest("[data-color]"); if (b) setSetting("accent", b.dataset.color); });
  $("#swatches").addEventListener("input", (e) => { if (e.target.id === "customColor") { state.settings.accent = e.target.value; applySheetStyle(); scheduleSave(); } });
  $("#swatches").addEventListener("change", (e) => { if (e.target.id === "customColor") setSetting("accent", e.target.value); });

  /* ---------- form ---------- */
  function renderForm() {
    const active = document.activeElement && document.activeElement.id;
    $("#formRoot").innerHTML = RC.formHTML(state.resume, open);
    if (active && $("#" + active)) $("#" + active).focus({ preventScroll: true });
  }
  function openSection(key, focusPath) {
    open.add(key); renderForm();
    const acc = $("#acc-" + key);
    acc.scrollIntoView({ block: "nearest", behavior: "smooth" });
    acc.classList.add("flash");
    if (focusPath) { const el = $(`#formRoot [data-path="${focusPath}"]`); if (el) el.focus({ preventScroll: true }); }
  }

  $("#formRoot").addEventListener("click", (e) => {
    const acc = e.target.closest("[data-acc]");
    if (acc) {
      const k = acc.dataset.acc;
      open.has(k) ? open.delete(k) : open.add(k);
      const el = $("#acc-" + k); el.classList.toggle("open", open.has(k)); acc.setAttribute("aria-expanded", open.has(k));
      return;
    }
    handleAction(e);
  });
  $("#formRoot").addEventListener("input", (e) => {
    const el = e.target, path = el.dataset.path;
    if (!path) return;
    RC.setPath(state.resume, path, el.dataset.type === "lines" ? el.value.split("\n") : el.value);
    renderPreview(true); scheduleSave();
  });

  /* ---------- shared add / remove / move ---------- */
  const NEW = {
    education: () => ({ degree: "", institution: "", year: "", score: "" }),
    experience: () => ({ role: "", company: "", duration: "", bullets: [""] }),
    projects: () => ({ name: "", tech: "", link: "", bullets: [""] }),
    skills: (preset) => ({ category: preset || "", items: "" })
  };
  const FIRST_FIELD = { education: "degree", experience: "role", projects: "name", skills: "category" };

  function snapshot() { undoSnap = JSON.stringify(state); }
  function undo() { if (!undoSnap) return; state = JSON.parse(undoSnap); undoSnap = null; applySettingsUI(); renderForm(); renderPreview(); scheduleSave(); }

  function handleAction(e) {
    const addB = e.target.closest("[data-add]"), rmB = e.target.closest("[data-rm]"), bulB = e.target.closest("[data-add-bullet]"), mvB = e.target.closest("[data-move]");
    if (addB) {
      const key = addB.dataset.add;
      state.resume[key].push(NEW[key](addB.dataset.preset));
      const i = state.resume[key].length - 1;
      renderForm(); renderPreview(); scheduleSave();
      const inPreview = !!addB.closest("#sheet");
      if (inPreview) { open.add(key); }
      focusPreview(`${key}.${i}.${FIRST_FIELD[key]}`);
      if (addB.closest("#formRoot")) { open.add(key); renderForm(); const el = $(`#formRoot [data-path="${key}.${i}.${FIRST_FIELD[key]}"]`); if (el) el.focus(); }
    } else if (rmB) {
      const [key, i] = rmB.dataset.rm.split(".");
      snapshot(); state.resume[key].splice(+i, 1);
      renderForm(); renderPreview(); scheduleSave();
      toast("Entry removed.", "Undo", undo);
    } else if (bulB) {
      const [key, i] = bulB.dataset.addBullet.split(".");
      const list = state.resume[key][+i].bullets; list.push("");
      renderForm(); renderPreview(); scheduleSave(); focusPreview(`${key}.${i}.bullets.${list.length - 1}`);
    } else if (mvB) {
      const [key, i, d] = mvB.dataset.move.split("."); const a = +i, b = a + +d, arr = state.resume[key];
      if (b < 0 || b >= arr.length) return;
      [arr[a], arr[b]] = [arr[b], arr[a]];
      renderForm(); renderPreview(); scheduleSave();
    }
  }

  function focusPreview(path) {
    if (document.body.dataset.view === "preview" || window.innerWidth > 900) {
      const el = $(`#sheet [data-path="${path}"]`);
      if (el) { el.focus(); const r = document.createRange(); r.selectNodeContents(el); r.collapse(false); const s = getSelection(); s.removeAllRanges(); s.addRange(r); el.scrollIntoView({ block: "nearest", behavior: "smooth" }); }
    }
  }

  /* ---------- preview ---------- */
  let renderTimer;
  function renderPreview(debounced) {
    clearTimeout(renderTimer);
    const run = () => {
      const t0 = performance.now();
      applySheetStyle();
      $("#sheet").innerHTML = RC.render(state);
      lastRenderMs = performance.now() - t0;
      fit(); updateMetrics();
    };
    debounced ? (renderTimer = setTimeout(run, 90)) : run();
  }

  function fit() {
    const sh = $("#sheet"), wrap = $("#sheetWrap"), box = $("#previewScroll");
    const w = sh.offsetWidth || 794;
    const avail = box.clientWidth - (window.innerWidth <= 900 ? 16 : 32);
    const s = zoom === "fit" ? Math.min(1, Math.max(0.3, avail / w)) : 1;
    sh.style.transform = `scale(${s})`;
    wrap.style.width = w * s + "px";
    wrap.style.height = sh.offsetHeight * s + "px";
  }
  function updateMetrics() {
    const m = $("#metrics"); m.hidden = !showMetrics;
    if (!showMetrics) return;
    const r = state.resume, pages = Math.max(1, Math.ceil($("#sheet").offsetHeight / A4_PX - 0.02));
    const words = JSON.stringify(r).replace(/[^\w\s]/g, " ").split(/\s+/).filter(Boolean).length;
    m.textContent = `Render ${lastRenderMs.toFixed(1)} ms · ${pages} A4 page${pages > 1 ? "s" : ""} · ${words} words · ${r.projects.length} projects · ${r.experience.length} experience · ${r.skills.reduce((n, s) => n + (s.items || "").split(",").filter((x) => x.trim()).length, 0)} skills`;
  }
  new ResizeObserver(fit).observe($("#previewScroll"));
  $("#zoomFit").addEventListener("click", () => setZoom("fit"));
  $("#zoom100").addEventListener("click", () => setZoom("100"));
  function setZoom(z) {
    zoom = z;
    $("#zoomFit").classList.toggle("is-on", z === "fit"); $("#zoomFit").setAttribute("aria-pressed", z === "fit");
    $("#zoom100").classList.toggle("is-on", z === "100"); $("#zoom100").setAttribute("aria-pressed", z === "100");
    fit();
  }

  /* ---------- inline editing on the sheet ---------- */
  const sheet = $("#sheet");
  sheet.addEventListener("input", (e) => {
    const el = e.target.closest("[data-path]"); if (!el) return;
    const path = el.dataset.path, val = el.textContent.replace(/\s*\n\s*/g, " ");
    RC.setPath(state.resume, path, val);
    const m = path.match(/^(\w+\.\d+)\.bullets\.\d+$/);
    const formEl = m ? $(`#formRoot [data-path="${m[1]}.bullets"]`) : $(`#formRoot [data-path="${path}"]`);
    if (formEl) formEl.value = m ? RC.getPath(state.resume, m[1] + ".bullets").join("\n") : val;
    fit(); updateMetrics(); scheduleSave();
  });
  sheet.addEventListener("keydown", (e) => {
    const el = e.target.closest("[data-path]");
    if (el && e.key === "Enter") {
      e.preventDefault();
      const m = el.dataset.path.match(/^(\w+\.\d+)\.bullets\.(\d+)$/);
      if (m && !e.shiftKey) {
        const list = RC.getPath(state.resume, m[1] + ".bullets"), n = +m[2] + 1;
        list.splice(n, 0, ""); renderForm(); renderPreview(); scheduleSave(); focusPreview(`${m[1]}.bullets.${n}`);
      }
    } else if (el && e.key === "Backspace" && el.tagName === "LI" && !el.textContent) {
      const m = el.dataset.path.match(/^(\w+\.\d+)\.bullets\.(\d+)$/);
      if (m) {
        e.preventDefault();
        const list = RC.getPath(state.resume, m[1] + ".bullets"), n = +m[2];
        list.splice(n, 1); renderForm(); renderPreview(); scheduleSave(); focusPreview(`${m[1]}.bullets.${Math.max(0, n - 1)}`);
      }
    } else if (e.target.closest("[data-jump]") && (e.key === "Enter" || e.key === " ")) {
      e.preventDefault(); jump(e.target.closest("[data-jump]"));
    }
  });
  sheet.addEventListener("click", (e) => {
    const j = e.target.closest("[data-jump]");
    if (j) return jump(j);
    handleAction(e);
  });
  function jump(el) {
    const path = el.dataset.jump; setView("edit"); openSection(path.split(".")[0], path);
  }

  /* ---------- header controls ---------- */
  const demoBtn = $("#demoBtn"), demoMenu = $("#demoMenu");
  function menu(show) { demoMenu.hidden = !show; demoBtn.setAttribute("aria-expanded", show); if (show) $("button", demoMenu).focus(); }
  demoBtn.addEventListener("click", () => menu(demoMenu.hidden));
  document.addEventListener("click", (e) => { if (!e.target.closest(".menu-wrap")) menu(false); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !demoMenu.hidden) { menu(false); demoBtn.focus(); } });
  demoMenu.addEventListener("keydown", (e) => {
    if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    e.preventDefault(); const items = $$("button", demoMenu), i = items.indexOf(document.activeElement);
    items[(i + (e.key === "ArrowDown" ? 1 : -1) + items.length) % items.length].focus();
  });
  demoMenu.addEventListener("click", (e) => {
    const a = e.target.closest("[data-action]"); if (!a) return;
    menu(false);
    const act = a.dataset.action;
    if (act === "show-metrics") { showMetrics = !showMetrics; updateMetrics(); return; }
    snapshot();
    state.resume = act === "load-heavy" ? RC.heavySample() : RC.studentSample();
    showMetrics = act === "load-heavy" || showMetrics;
    renderForm(); renderPreview(); scheduleSave();
    const pages = Math.max(1, Math.ceil($("#sheet").offsetHeight / A4_PX - 0.02));
    toast(act === "load-heavy" ? `Stress test loaded: rendered in ${lastRenderMs.toFixed(1)} ms, ${pages} pages, no clipping.` : "Student sample loaded.", "Undo", undo);
  });

  $("#resetBtn").addEventListener("click", () => {
    if (!confirm("Start a new, blank resume? Your current draft will be cleared (you can undo right after).")) return;
    snapshot(); state.resume = RC.blankResume(); open = new Set(["personal"]);
    renderForm(); renderPreview(); scheduleSave(); toast("New blank resume.", "Undo", undo);
  });
  $("#printBtn").addEventListener("click", () => { saveNow(); window.print(); });

  const hcBtn = $("#contrastBtn");
  function setHC(on) { document.body.classList.toggle("hc", on); hcBtn.setAttribute("aria-pressed", on); store.set(K.hc, on); }
  hcBtn.addEventListener("click", () => setHC(!document.body.classList.contains("hc")));

  $("#styleToggle").addEventListener("click", (e) => {
    const on = $(".toolbar").classList.toggle("open"); e.currentTarget.setAttribute("aria-expanded", on);
  });

  /* ---------- mobile Edit / Preview tabs ---------- */
  function setView(v) {
    document.body.dataset.view = v;
    $$(".mobile-tabs [role=tab]").forEach((t) => t.setAttribute("aria-selected", t.dataset.view === v));
    if (v === "preview") requestAnimationFrame(fit);
  }
  $$(".mobile-tabs [role=tab]").forEach((t) => t.addEventListener("click", () => setView(t.dataset.view)));

  /* ---------- boot ---------- */
  setHC(!!store.get(K.hc, false));
  const sess = store.get(K.session);
  sess ? startSession(sess) : showAuth();
})();
