/* ResumeCraft — data model, defaults and demo presets */
"use strict";

const RC = {};

RC.ACCENTS = ["#14532D", "#B45309", "#18181B", "#9F1239", "#0F766E", "#78350F"];

RC.blankResume = () => ({
  personal: { name: "", role: "", email: "", phone: "", location: "", linkedin: "", github: "" },
  summary: "",
  education: [],
  experience: [],
  projects: [],
  skills: []
});

RC.defaultSettings = () => ({ template: "classic", accent: "#14532D", font: "inter", size: "1", space: "1" });

RC.studentSample = () => ({
  personal: {
    name: "Akshata Goliat", role: "B.Tech Computer Science Student · Full-Stack Developer",
    email: "akshata.goliat@example.com", phone: "+91 98765 43210", location: "Pune, India",
    linkedin: "linkedin.com/in/akshatagoliat", github: "github.com/akshatagoliat"
  },
  summary: "Final-year Computer Science student with hands-on experience building REST APIs and responsive web apps. Solved 400+ problems on competitive platforms and shipped three projects used by 1,000+ students. Looking for a software engineering internship where I can write clean, tested code.",
  education: [
    { degree: "B.Tech, Computer Science & Engineering", institution: "MIT Academy of Engineering, Pune", year: "2022 – 2026", score: "CGPA: 8.7 / 10" },
    { degree: "Higher Secondary (HSC), Science", institution: "St. Xavier's Junior College, Pune", year: "2020 – 2022", score: "92.4%" }
  ],
  experience: [
    {
      role: "Software Engineering Intern", company: "Zenith Labs Pvt. Ltd.", duration: "May 2025 – Jul 2025",
      bullets: [
        "Built 6 REST endpoints in Node.js and Express that cut report generation time by 38%.",
        "Wrote 45 Jest unit tests, raising backend coverage from 41% to 78%.",
        "Collaborated with a team of 5 in two-week agile sprints using Git and Jira."
      ]
    }
  ],
  projects: [
    {
      name: "CampusConnect — Student Events Platform", tech: "React, Node.js, MongoDB, Tailwind CSS", link: "github.com/akshatagoliat/campusconnect",
      bullets: [
        "Event discovery and RSVP platform used by 1,200+ students across 14 clubs.",
        "Implemented JWT authentication and role-based access for organizers and attendees."
      ]
    },
    {
      name: "ResumeCraft — ATS-friendly Resume Builder", tech: "HTML, CSS, JavaScript", link: "resumecraft.netlify.app",
      bullets: [
        "Zero-dependency resume builder with live A4 preview and print-ready PDF export.",
        "Autosaves to localStorage and scores 100 on Lighthouse accessibility."
      ]
    }
  ],
  skills: [
    { category: "Languages", items: "JavaScript, Python, Java, C++, SQL" },
    { category: "Frameworks", items: "React, Node.js, Express, Flask, Tailwind CSS" },
    { category: "Tools", items: "Git, GitHub, Docker, Postman, VS Code, Figma" }
  ]
});

RC.heavySample = () => {
  const long = "Designed, implemented and load-tested the service end to end, writing detailed technical documentation, automated regression suites and monitoring dashboards so the whole team could safely iterate on the system without regressions or unexpected downtime";
  const exp = (role, company, duration, n) => ({
    role, company, duration,
    bullets: [
      `${long}, reducing p95 latency from 1.8s to 420ms across 2.4M monthly requests.`,
      `Led migration of a legacy monolith module to event-driven microservices using Kafka and PostgreSQL, coordinating with four teams across three time zones and presenting weekly progress updates to senior leadership (${n} releases shipped).`,
      "Mentored 3 junior engineers through code reviews and pair-programming sessions; two were converted to full-time roles.",
      "Automated CI/CD with GitHub Actions and Terraform, cutting deployment time from 45 minutes to 6 minutes and eliminating manual release errors."
    ]
  });
  const proj = (name, tech, link, i) => ({
    name, tech, link,
    bullets: [
      `${long}. Handled ${i * 3 + 7}k concurrent users in load tests with zero data loss and graceful degradation under failure.`,
      "Built a responsive, accessible interface (WCAG 2.1 AA) with keyboard navigation, screen-reader labels and a high-contrast mode validated with axe and manual testing.",
      "Added observability: structured logging, distributed tracing and alerting that cut mean-time-to-resolution by 55% during on-call drills."
    ]
  });
  return {
    personal: {
      name: "Priya Venkatakrishnan-Subramanian", role: "Senior Full-Stack & Cloud Engineer · Open-Source Contributor",
      email: "priya.venkatakrishnan@example.com", phone: "+91 90000 12345", location: "Bengaluru, Karnataka, India",
      linkedin: "linkedin.com/in/priya-venkatakrishnan-subramanian", github: "github.com/priya-vs"
    },
    summary: "Results-driven software engineer with experience designing scalable, secure and maintainable systems across web, cloud and data platforms. Strong track record of shipping high-impact features, improving reliability and mentoring teammates. " + long + ". Passionate about developer experience, performance engineering, accessibility and open-source collaboration.",
    education: [
      { degree: "B.Tech, Computer Science & Engineering (Honours in Distributed Systems)", institution: "National Institute of Technology, Tiruchirappalli", year: "2021 – 2025", score: "CGPA: 9.12 / 10" },
      { degree: "Higher Secondary (CBSE), PCM + Computer Science", institution: "Delhi Public School, Bengaluru", year: "2019 – 2021", score: "96.8%" }
    ],
    experience: [
      exp("Software Engineering Intern — Platform", "Northwind Cloud Technologies", "Jan 2025 – Jun 2025", 9),
      exp("Backend Engineering Intern", "Finlytics Data Systems Pvt. Ltd.", "Jun 2024 – Aug 2024", 5),
      exp("Open-Source Intern (Summer of Code)", "The Apache Software Foundation", "May 2023 – Aug 2023", 4)
    ],
    projects: [
      proj("DistriCache — Distributed In-Memory Cache", "Go, gRPC, Raft, Docker, Kubernetes", "github.com/priya-vs/districache", 1),
      proj("StudyBuddy — Collaborative Learning Platform", "React, TypeScript, Node.js, PostgreSQL, Redis, WebSockets", "studybuddy.example.com", 2),
      proj("PixelPipe — Image Processing Pipeline", "Python, FastAPI, Celery, RabbitMQ, AWS S3, Lambda", "github.com/priya-vs/pixelpipe", 3),
      proj("HealthTrack — Cross-Platform Fitness App", "React Native, Firebase, GraphQL, Apollo", "github.com/priya-vs/healthtrack", 4),
      proj("ResumeCraft — ATS-friendly Resume Builder", "HTML5, CSS3, Vanilla JavaScript, localStorage", "github.com/priya-vs/resumecraft", 5)
    ],
    skills: [
      { category: "Languages", items: "JavaScript, TypeScript, Python, Java, Go, C++, SQL, Bash, Rust, Kotlin" },
      { category: "Frameworks", items: "React, Next.js, Node.js, Express, FastAPI, Spring Boot, Django, GraphQL, Tailwind CSS" },
      { category: "Tools", items: "Git, Docker, Kubernetes, Terraform, GitHub Actions, AWS, PostgreSQL, MongoDB, Redis, Kafka, Grafana, Jest, Cypress, Figma" }
    ]
  };
};
