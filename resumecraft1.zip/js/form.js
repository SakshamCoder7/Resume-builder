/* ResumeCraft — left-panel accordion form builder */
"use strict";

RC.SECTIONS = [
  { key: "personal", title: "Personal Info" },
  { key: "summary", title: "Professional Summary" },
  { key: "education", title: "Education" },
  { key: "experience", title: "Experience / Internships" },
  { key: "projects", title: "Projects" },
  { key: "skills", title: "Skills" }
];

const idOf = (path) => "f-" + path.replace(/\./g, "-");

const field = (r, path, label, opts = {}) => {
  const { type = "text", ph = "", area = false, hint = "", auto = "" } = opts;
  let val = RC.getPath(r, path);
  if (Array.isArray(val)) val = val.join("\n");
  const id = idOf(path);
  const attrs = `id="${id}" data-path="${path}"${opts.lines ? ' data-type="lines"' : ""} placeholder="${RC.esc(ph)}"${auto ? ` autocomplete="${auto}"` : ""}`;
  const input = area
    ? `<textarea ${attrs} rows="${opts.rows || 4}" aria-describedby="${id}-h">${RC.esc(val)}</textarea>`
    : `<input type="${type}" ${attrs} value="${RC.esc(val)}">`;
  return `<div class="field"><label for="${id}">${label}</label>${input}${hint ? `<span class="hint" id="${id}-h">${hint}</span>` : ""}</div>`;
};

const entryHead = (key, i, label) =>
  `<div class="entry-head"><span>${label} ${i + 1}</span><span class="entry-actions">
    <button type="button" class="btn btn-sm btn-ghost" data-move="${key}.${i}.-1" aria-label="Move ${label} ${i + 1} up"${i === 0 ? " disabled" : ""}>↑</button>
    <button type="button" class="btn btn-sm btn-ghost" data-move="${key}.${i}.1" aria-label="Move ${label} ${i + 1} down">↓</button>
    <button type="button" class="btn btn-sm btn-ghost btn-danger" data-rm="${key}.${i}" aria-label="Remove ${label} ${i + 1}">Remove</button></span></div>`;

const addBtn = (key, label) => `<button type="button" class="add-btn" data-add="${key}">+ Add ${label}</button>`;

const BODY = {
  personal: (r) => `
    <div class="grid-2">${field(r, "personal.name", "Full name", { ph: "Akshata Goliat", auto: "name" })}${field(r, "personal.role", "Role / Headline", { ph: "Full-Stack Developer" })}</div>
    <div class="grid-2">${field(r, "personal.email", "Email", { type: "email", ph: "you@example.com", auto: "email" })}${field(r, "personal.phone", "Phone", { type: "tel", ph: "+91 98765 43210", auto: "tel" })}</div>
    ${field(r, "personal.location", "Location", { ph: "City, Country", auto: "address-level2" })}
    <div class="grid-2">${field(r, "personal.linkedin", "LinkedIn", { ph: "linkedin.com/in/you" })}${field(r, "personal.github", "GitHub / Portfolio", { ph: "github.com/you" })}</div>`,

  summary: (r) => field(r, "summary", "Professional summary", { area: true, rows: 5, ph: "2–3 sentences: who you are, what you build, what you want next.", hint: "Tip: keep it under 60 words. Lead with your strongest fact." }),

  education: (r) => r.education.map((e, i) => `<div class="entry">${entryHead("education", i, "Education")}
      ${field(r, `education.${i}.degree`, "Degree", { ph: "B.Tech, Computer Science" })}
      ${field(r, `education.${i}.institution`, "Institution", { ph: "University / College" })}
      <div class="grid-2">${field(r, `education.${i}.year`, "Year", { ph: "2022 – 2026" })}${field(r, `education.${i}.score`, "CGPA / Percentage", { ph: "CGPA: 8.5 / 10" })}</div></div>`).join("") + addBtn("education", "education"),

  experience: (r) => r.experience.map((e, i) => `<div class="entry">${entryHead("experience", i, "Experience")}
      <div class="grid-2">${field(r, `experience.${i}.role`, "Role", { ph: "Software Intern" })}${field(r, `experience.${i}.company`, "Company", { ph: "Company name" })}</div>
      ${field(r, `experience.${i}.duration`, "Duration", { ph: "May 2025 – Jul 2025" })}
      ${field(r, `experience.${i}.bullets`, "Bullet points", { area: true, lines: true, rows: 5, ph: "One achievement per line", hint: "One bullet per line. Start with a verb and add a number." })}</div>`).join("") + addBtn("experience", "experience / internship"),

  projects: (r) => r.projects.map((p, i) => `<div class="entry">${entryHead("projects", i, "Project")}
      <div class="grid-2">${field(r, `projects.${i}.name`, "Project name", { ph: "My Project" })}${field(r, `projects.${i}.link`, "Live / Repo link", { ph: "github.com/you/project" })}</div>
      ${field(r, `projects.${i}.tech`, "Tech stack", { ph: "React, Node.js, MongoDB" })}
      ${field(r, `projects.${i}.bullets`, "Description bullets", { area: true, lines: true, rows: 4, ph: "One point per line", hint: "One bullet per line." })}</div>`).join("") + addBtn("projects", "project"),

  skills: (r) => r.skills.map((s, i) => `<div class="entry">${entryHead("skills", i, "Category")}
      <div class="grid-2">${field(r, `skills.${i}.category`, "Category", { ph: "Languages" })}${field(r, `skills.${i}.items`, "Skills (comma-separated)", { ph: "JavaScript, Python, SQL" })}</div></div>`).join("") +
    `<div class="hint" style="margin-bottom:8px">Quick add:
      <button type="button" class="link-btn" data-add="skills" data-preset="Languages">Languages</button> ·
      <button type="button" class="link-btn" data-add="skills" data-preset="Frameworks">Frameworks</button> ·
      <button type="button" class="link-btn" data-add="skills" data-preset="Tools">Tools</button></div>` + addBtn("skills", "skill category")
};

const COUNT = {
  education: (r) => r.education.length, experience: (r) => r.experience.length,
  projects: (r) => r.projects.length, skills: (r) => r.skills.length
};

RC.formHTML = (r, open) => RC.SECTIONS.map(({ key, title }) => {
  const isOpen = open.has(key);
  const count = COUNT[key] ? `<span class="count">${COUNT[key](r)}</span>` : "";
  return `<section class="acc${isOpen ? " open" : ""}" id="acc-${key}">
    <h3 style="font-size:inherit"><button type="button" class="acc-head" id="acc-${key}-h" aria-expanded="${isOpen}" aria-controls="acc-${key}-b" data-acc="${key}">
      <span class="chev" aria-hidden="true">▸</span>${title}${count}</button></h3>
    <div class="acc-body" id="acc-${key}-b" role="region" aria-labelledby="acc-${key}-h">${BODY[key](r)}</div></section>`;
}).join("");
