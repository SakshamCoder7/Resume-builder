# ResumeCraft — Online Resume Builder (HTML + CSS + JavaScript only)

No frameworks, no build step, no dependencies. Fonts load from Google Fonts (falls back to system fonts offline).

## Run locally
Open `index.html` in a browser (or `python3 -m http.server` in this folder).

## Deploy to Netlify
1. Go to https://app.netlify.com/drop
2. Drag this whole folder (or the unzipped folder) onto the page. Done.
   (Or: connect a Git repo, build command: *none*, publish directory: `.`)

## Structure
- `index.html` – auth screen, header, template bar, editor, live preview
- `css/app.css` – app UI (paper / ink / forest-green theme, high-contrast mode, responsive)
- `css/resume.css` – the 3 resume templates (ATS Classic, Modern Editorial, Executive Minimal)
- `css/print.css` – `@media print` rules: exports ONLY the A4 resume
- `js/data.js` – data model + Student / Heavy stress-test presets
- `js/templates.js` – template renderers (inline-editable markup)
- `js/form.js` – accordion form builder
- `js/app.js` – login, localStorage autosave, preview, zoom, colour/font controls, demo tools

## Features
- Sign in (local) or Continue as Guest; drafts autosave to localStorage per user
- Split-screen editor + debounced live A4 preview, Fit / 100% zoom
- Click any text on the resume to edit it; **+** on every section adds entries directly on the page
- 3 templates, 6 accent colours + custom colour, 7 fonts, text size and spacing controls
- Download / Print PDF (use "Save as PDF", set Margins: Default, untick "Headers and footers")
- Demo & Testing Tools: Student sample, Heavy stress test, render metrics
- High-contrast mode, ARIA labels, focus rings, mobile Edit / Preview tabs
